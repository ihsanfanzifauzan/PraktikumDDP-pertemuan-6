jumlah_baris = int(input("Masukkan jumalah baris: "))

for i in range(1, jumlah_baris + 1):
         print("*" * i)
